package flightManagementSystem;

import flightManagementSystem.gui.InputMask;


/**
 *  @author landev
 */
// <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
// #[regen=yes,id=DCE.0CFE5C17-DA6A-168C-42EA-128D48AF0077]
// </editor-fold> 
public class Main {

    /**
     *  @param args the command line arguments
     */
    // <editor-fold defaultstate="collapsed" desc=" UML Marker "> 
    // #[regen=yes,id=DCE.31B1F2E4-91DB-E0DE-72D0-4304C16403C2]
    // </editor-fold> 
    public static void main (String[] args) {
        InputMask gui = new InputMask();
    }
}