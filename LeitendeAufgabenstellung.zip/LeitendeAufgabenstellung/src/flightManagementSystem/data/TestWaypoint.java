/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package flightManagementSystem.data;

/**
 *
 * @author landev
 */
public class TestWaypoint {

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        String[] data = {"test", "test", "n89600", "E006066"};
        try {
            Waypoint myWaypoint = new Waypoint(data);
        } catch (java.lang.Exception e) {
            System.out.println("ERROR");
        }
        String[] data2 = {"test", "test", "n89601", "E006066"};
        
        try {
            Waypoint myWaypoint = new Waypoint(data2);
        } catch (java.lang.Exception e) {
            System.out.println("ERROR");
        }
                String[] data3 = {"test", "test", "n89600", "E179600"};
        try {
            Waypoint myWaypoint = new Waypoint(data3);
        } catch (java.lang.Exception e) {
            System.out.println("ERROR");
        }
        String[] data4 = {"test", "test", "n89600", "E179601"};
        
        try {
            Waypoint myWaypoint = new Waypoint(data4);
        } catch (java.lang.Exception e) {
            System.out.println("ERROR");
        }
        
        try {
            Waypoint myWaypoint = new Waypoint();
        } catch (java.lang.Exception e) {
            System.out.println("ERROR");
        }
        
        
    }
}
