/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 * 
 * Kleine Bemerkung zu dieser Datei, die ist nicht geklaut, aber auch nicht von uns...
 */

package flightManagementSystem.gui;

import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JComponent;

public class BackgroundImagePanel extends JComponent {
 
	private Image backgroundImage = null;
 
	/**
	 * Constructor
	 */
	public BackgroundImagePanel() {
		super();
	}
 
	/**
	 * Returns the background image
	 * @return	Background image
	 */
	public Image getBackgroundImage() {
		return backgroundImage;
	}
 
	/**
	 * Sets the background image
	 * @param backgroundImage	Background image
	 */
	public void setBackgroundImage(Image backgroundImage) {
		this.backgroundImage = backgroundImage;
	}
	
	/**
	 * Overrides the painting to display a background image
	 */
	protected void paintComponent(Graphics g) {
		if (isOpaque()) {
			g.setColor(getBackground());
			g.fillRect(0, 0, getWidth(), getHeight());
		}
		if (backgroundImage != null) {
			g.drawImage(backgroundImage,0,0,this);
		}
	}
 
}



