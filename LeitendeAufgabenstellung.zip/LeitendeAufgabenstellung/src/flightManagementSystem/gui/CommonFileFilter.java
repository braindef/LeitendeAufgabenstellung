/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package flightManagementSystem.gui;

import java.io.File;
import javax.swing.filechooser.FileFilter;


/**
 *
 * @author marc
 */
public class CommonFileFilter extends FileFilter {
    
    public String extension;
    
    
    public CommonFileFilter()
    {
        extension = "txt";
    }
    
    
    public CommonFileFilter(String pExtension)
    {
        extension = pExtension;
    }
    
    
    public boolean accept(File f) {
        return f.isDirectory() || f.getName().toLowerCase().endsWith("."+extension.toLowerCase());
    }
    
    public String getDescription() {
        return "."+extension+ " files";
    }
    
    public String getExtension(){
        return "."+extension;
        
    }
}
