/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package flightManagementSystem.logic;

import java.text.DecimalFormat;

/**
 *
 * @author filu
 */
public class Utils {
    // Auf 2 Stellen runden
    /**
     * 
     * @param pValue
     * @return
     */
    public static String round(double pValue) {
        pValue = Math.round( pValue * 100 ) / 100.0;
        DecimalFormat df = new DecimalFormat("#.00");    
        return df.format(pValue);
    }
}
